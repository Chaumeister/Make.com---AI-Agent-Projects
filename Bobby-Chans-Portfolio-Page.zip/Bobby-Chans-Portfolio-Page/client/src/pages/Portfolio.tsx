import Navigation from "@/components/Navigation";
import Hero from "@/components/Hero";
import About from "@/components/About";
import Goals from "@/components/Goals";
import Skills from "@/components/Skills";
import Projects from "@/components/Projects";
import CourseLearnings from "@/components/CourseLearnings";
import Resume from "@/components/Resume";
import Contact from "@/components/Contact";

export default function Portfolio() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <Hero />
      <About />
      <Goals />
      <Skills />
      <Projects />
      <CourseLearnings />
      <Resume />
      <Contact />
    </div>
  );
}
