import { Download, Briefcase, GraduationCap, Award } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const experience = [
  {
    id: "senior-dev",
    role: "Technology Risk Consultant",
    company: "ConsultForMe",
    period: "2024 - Present",
    achievements: [
      "Delivered enterprise technology solutions improving client risk posture by 50%+",
      "Led AI integration initiatives for multiple Fortune 500 clients",
      "Developed comprehensive risk assessment frameworks adopted firm-wide",
    ],
  },
];

const education = [
  {
    id: "bs-cs",
    degree: "Bachelor of Science in Information Systems",
    institution: "Binghamton University School of Management",
    period: "2020 - 2024",
    achievements: [
      "Graduated with Honors (GPA: 3.9/4.0)",
      "Focus on Technology Risk Management and AI Applications",
      "Led student consulting projects for local businesses",
    ],
  },
];

const leadership = [
  {
    id: "eagle-scout",
    role: "Eagle Scout",
    organization: "Boy Scouts of America",
    period: "2015 - 2020",
    achievements: [
      "Led Eagle Scout project to improve local elementary school's playground infrastructure",
      "Coordinated team of 15 scouts in playground equipment renovation and safety improvements",
      "Designed and implemented garden beautification project with flowers and shrubs",
      "Managed project budget and secured donations from local businesses",
    ],
  },
];

export default function Resume() {
  const handleDownload = () => {
    console.log("Download PDF Resume triggered");
  };

  return (
    <section id="resume" className="py-16 md:py-24 bg-card">
      <div className="max-w-6xl mx-auto px-4">
        <h2
          className="text-3xl md:text-4xl font-bold mb-12 text-center"
          data-testid="text-resume-heading"
        >
          Resume
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-12">
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-primary/10 p-2 rounded-lg">
                  <Briefcase className="h-5 w-5 text-primary" />
                </div>
                <h3 className="text-2xl font-semibold">Professional Experience</h3>
              </div>
              <div className="space-y-6">
                {experience.map((job) => (
                  <Card key={job.id} data-testid={`card-experience-${job.id}`}>
                    <CardContent className="pt-6">
                      <div className="flex flex-col sm:flex-row sm:items-baseline sm:justify-between gap-2 mb-3">
                        <h4
                          className="text-xl font-semibold"
                          data-testid={`text-role-${job.id}`}
                        >
                          {job.role}
                        </h4>
                        <span
                          className="text-sm text-muted-foreground"
                          data-testid={`text-period-${job.id}`}
                        >
                          {job.period}
                        </span>
                      </div>
                      <p
                        className="text-muted-foreground mb-3"
                        data-testid={`text-company-${job.id}`}
                      >
                        {job.company}
                      </p>
                      <ul className="space-y-2">
                        {job.achievements.map((achievement, index) => (
                          <li
                            key={index}
                            className="text-muted-foreground flex gap-2"
                            data-testid={`text-achievement-${job.id}-${index}`}
                          >
                            <span className="text-primary mt-1">•</span>
                            <span>{achievement}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-primary/10 p-2 rounded-lg">
                  <GraduationCap className="h-5 w-5 text-primary" />
                </div>
                <h3 className="text-2xl font-semibold">Education</h3>
              </div>
              <div className="space-y-6">
                {education.map((edu) => (
                  <Card key={edu.id} data-testid={`card-education-${edu.id}`}>
                    <CardContent className="pt-6">
                      <div className="flex flex-col sm:flex-row sm:items-baseline sm:justify-between gap-2 mb-3">
                        <h4
                          className="text-xl font-semibold"
                          data-testid={`text-degree-${edu.id}`}
                        >
                          {edu.degree}
                        </h4>
                        <span
                          className="text-sm text-muted-foreground"
                          data-testid={`text-edu-period-${edu.id}`}
                        >
                          {edu.period}
                        </span>
                      </div>
                      <p
                        className="text-muted-foreground mb-3"
                        data-testid={`text-institution-${edu.id}`}
                      >
                        {edu.institution}
                      </p>
                      <ul className="space-y-2">
                        {edu.achievements.map((achievement, index) => (
                          <li
                            key={index}
                            className="text-muted-foreground flex gap-2"
                            data-testid={`text-edu-achievement-${edu.id}-${index}`}
                          >
                            <span className="text-primary mt-1">•</span>
                            <span>{achievement}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-primary/10 p-2 rounded-lg">
                  <Award className="h-5 w-5 text-primary" />
                </div>
                <h3 className="text-2xl font-semibold">Leadership Experience</h3>
              </div>
              <div className="space-y-6">
                {leadership.map((lead) => (
                  <Card key={lead.id} data-testid={`card-leadership-${lead.id}`}>
                    <CardContent className="pt-6">
                      <div className="flex flex-col sm:flex-row sm:items-baseline sm:justify-between gap-2 mb-3">
                        <h4
                          className="text-xl font-semibold"
                          data-testid={`text-leadership-role-${lead.id}`}
                        >
                          {lead.role}
                        </h4>
                        <span
                          className="text-sm text-muted-foreground"
                          data-testid={`text-leadership-period-${lead.id}`}
                        >
                          {lead.period}
                        </span>
                      </div>
                      <p
                        className="text-muted-foreground mb-3"
                        data-testid={`text-organization-${lead.id}`}
                      >
                        {lead.organization}
                      </p>
                      <ul className="space-y-2">
                        {lead.achievements.map((achievement, index) => (
                          <li
                            key={index}
                            className="text-muted-foreground flex gap-2"
                            data-testid={`text-leadership-achievement-${lead.id}-${index}`}
                          >
                            <span className="text-primary mt-1">•</span>
                            <span>{achievement}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-1">
            <Card className="sticky top-24">
              <CardContent className="pt-6">
                <h3 className="text-xl font-semibold mb-4">Download Resume</h3>
                <p className="text-muted-foreground mb-6">
                  Get a PDF copy of my complete resume with detailed work history and accomplishments.
                </p>
                <Button
                  className="w-full"
                  size="lg"
                  onClick={handleDownload}
                  data-testid="button-download-resume"
                >
                  <Download className="h-5 w-5 mr-2" />
                  Download PDF
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
