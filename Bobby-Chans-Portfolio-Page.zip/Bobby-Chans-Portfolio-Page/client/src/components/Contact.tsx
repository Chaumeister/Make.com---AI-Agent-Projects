import { Mail, Linkedin, Github, Twitter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

const socialLinks = [
  { icon: Linkedin, label: "LinkedIn", url: "#", color: "text-blue-600" },
  { icon: Github, label: "GitHub", url: "#", color: "text-foreground" },
  { icon: Twitter, label: "Twitter", url: "#", color: "text-blue-400" },
  { icon: Mail, label: "Email", url: "mailto:bobby.chan@consultforme.com", color: "text-red-500" },
];

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    toast({
      title: "Message sent!",
      description: "Thank you for reaching out. I'll get back to you soon.",
    });
    setFormData({ name: "", email: "", message: "" });
  };

  return (
    <section id="contact" className="py-16 md:py-24 bg-background">
      <div className="max-w-6xl mx-auto px-4">
        <h2
          className="text-3xl md:text-4xl font-bold mb-12 text-center"
          data-testid="text-contact-heading"
        >
          Get In Touch
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>Send a Message</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label htmlFor="name" className="text-sm font-medium mb-2 block">
                    Name
                  </label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Your name"
                    required
                    data-testid="input-name"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="text-sm font-medium mb-2 block">
                    Email
                  </label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="your.email@example.com"
                    required
                    data-testid="input-email"
                  />
                </div>
                <div>
                  <label htmlFor="message" className="text-sm font-medium mb-2 block">
                    Message
                  </label>
                  <Textarea
                    id="message"
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Your message..."
                    rows={5}
                    required
                    data-testid="input-message"
                  />
                </div>
                <Button type="submit" className="w-full" data-testid="button-send-message">
                  Send Message
                </Button>
              </form>
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">Email</h4>
                  <a
                    href="mailto:bobby.chan@consultforme.com"
                    className="text-muted-foreground hover:text-primary"
                    data-testid="link-email"
                  >
                    bobby.chan@consultforme.com
                  </a>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Availability</h4>
                  <p className="text-muted-foreground" data-testid="text-availability">
                    Open to consulting opportunities and networking
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Response Time</h4>
                  <p className="text-muted-foreground" data-testid="text-response-time">
                    Usually within 24 hours
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Connect With Me</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-3">
                  {socialLinks.map((social) => {
                    const Icon = social.icon;
                    return (
                      <Button
                        key={social.label}
                        variant="outline"
                        asChild
                        className="justify-start"
                        data-testid={`button-social-${social.label.toLowerCase()}`}
                      >
                        <a href={social.url} target="_blank" rel="noopener noreferrer">
                          <Icon className={`h-5 w-5 mr-2 ${social.color}`} />
                          {social.label}
                        </a>
                      </Button>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <footer className="mt-16 pt-8 border-t text-center">
        <p className="text-muted-foreground text-sm" data-testid="text-copyright">
          © 2024 Bobby Chan. All rights reserved.
        </p>
        <div className="flex justify-center gap-4 mt-4">
          <button
            onClick={() => {
              const element = document.querySelector("#about");
              element?.scrollIntoView({ behavior: "smooth" });
            }}
            className="text-sm text-muted-foreground hover:text-primary"
            data-testid="link-footer-about"
          >
            About
          </button>
          <button
            onClick={() => {
              const element = document.querySelector("#projects");
              element?.scrollIntoView({ behavior: "smooth" });
            }}
            className="text-sm text-muted-foreground hover:text-primary"
            data-testid="link-footer-projects"
          >
            Projects
          </button>
          <button
            onClick={() => {
              const element = document.querySelector("#contact");
              element?.scrollIntoView({ behavior: "smooth" });
            }}
            className="text-sm text-muted-foreground hover:text-primary"
            data-testid="link-footer-contact"
          >
            Contact
          </button>
        </div>
      </footer>
    </section>
  );
}
