import { GraduationCap } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const courses = [
  {
    id: "advanced-web-dev",
    name: "Enterprise Risk Management",
    institution: "Binghamton University School of Management",
    learnings: [
      "Comprehensive framework for identifying, assessing, and mitigating enterprise risks",
      "Strategic approaches to integrating risk management with business objectives",
      "Quantitative and qualitative risk assessment methodologies",
      "Best practices for risk governance and oversight structures",
      "Regulatory compliance requirements across multiple industries",
    ],
    skills: ["Risk Assessment", "Compliance", "Governance", "Strategic Planning"],
  },
  {
    id: "database-systems",
    name: "Artificial Intelligence for Business",
    institution: "Harvard Business School",
    learnings: [
      "Understanding AI and machine learning applications in enterprise settings",
      "Implementing AI solutions to solve complex business problems",
      "Ethical considerations and governance frameworks for AI deployment",
      "Data analytics and predictive modeling for business intelligence",
      "Change management strategies for AI adoption in organizations",
    ],
    skills: ["AI/ML", "Data Analytics", "Business Intelligence", "Change Management"],
  },
  {
    id: "algorithms",
    name: "Cybersecurity & Technology Risk",
    institution: "Harvard Business School",
    learnings: [
      "Comprehensive understanding of cybersecurity threats and vulnerabilities",
      "Risk assessment frameworks specific to technology and information systems",
      "Implementation of security controls and incident response procedures",
      "Compliance with industry standards including ISO 27001, NIST, and SOC 2",
      "Cloud security best practices and zero-trust architecture principles",
    ],
    skills: ["Cybersecurity", "Cloud Security", "Compliance", "Risk Management"],
  },
  {
    id: "cloud-computing",
    name: "Cloud Computing & Digital Transformation",
    institution: "Coursera",
    learnings: [
      "Strategic approaches to cloud migration and digital transformation initiatives",
      "Hands-on experience with Azure and AWS cloud platforms and services",
      "Cost optimization and resource management in cloud environments",
      "Implementation of cloud governance and security frameworks",
      "Business case development for cloud adoption and ROI analysis",
    ],
    skills: ["Azure", "AWS", "Digital Transformation", "Cloud Strategy"],
  },
];

export default function CourseLearnings() {
  return (
    <section id="courses" className="py-16 md:py-24 bg-background">
      <div className="max-w-6xl mx-auto px-4">
        <h2
          className="text-3xl md:text-4xl font-bold mb-12 text-center"
          data-testid="text-courses-heading"
        >
          Course Learnings
        </h2>

        <Accordion type="single" collapsible className="space-y-4">
          {courses.map((course) => (
            <AccordionItem
              key={course.id}
              value={course.id}
              className="bg-card border border-card-border rounded-lg px-6"
              data-testid={`accordion-course-${course.id}`}
            >
              <AccordionTrigger className="hover:no-underline py-6">
                <div className="flex items-start gap-4 text-left w-full">
                  <div className="bg-primary/10 p-2 rounded-lg flex-shrink-0">
                    <GraduationCap className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3
                      className="text-xl font-semibold mb-1"
                      data-testid={`text-course-name-${course.id}`}
                    >
                      {course.name}
                    </h3>
                    <p
                      className="text-sm text-muted-foreground"
                      data-testid={`text-course-institution-${course.id}`}
                    >
                      {course.institution}
                    </p>
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent className="pt-4 pb-6">
                <div className="space-y-6 ml-14">
                  <div>
                    <h4 className="font-semibold mb-3">Key Learnings:</h4>
                    <ul className="space-y-2">
                      {course.learnings.map((learning, index) => (
                        <li
                          key={index}
                          className="text-muted-foreground flex gap-2"
                          data-testid={`text-learning-${course.id}-${index}`}
                        >
                          <span className="text-primary mt-1">•</span>
                          <span>{learning}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-3">Skills Gained:</h4>
                    <div className="flex flex-wrap gap-2">
                      {course.skills.map((skill) => (
                        <Badge
                          key={skill}
                          variant="secondary"
                          data-testid={`badge-course-skill-${course.id}-${skill.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}
                        >
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}
