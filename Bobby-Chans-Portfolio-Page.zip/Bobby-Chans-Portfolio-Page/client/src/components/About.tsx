import profileImage from "@assets/generated_images/Bobby_Chan_professional_headshot_9a9e9887.png";

export default function About() {
  return (
    <section id="about" className="py-16 md:py-24 bg-background">
      <div className="max-w-6xl mx-auto px-4">
        <h2
          className="text-3xl md:text-4xl font-bold mb-12 text-center"
          data-testid="text-about-heading"
        >
          About Me
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="flex justify-center">
            <img
              src={profileImage}
              alt="Bobby Chan"
              className="w-80 h-80 object-cover rounded-lg shadow-lg"
              data-testid="img-profile"
            />
          </div>

          <div className="space-y-6">
            <p className="text-base md:text-lg leading-relaxed" data-testid="text-bio-1">
              Hi, I'm Bobby Chan, a Technology Risk Consultant at ConsultForMe. I began my career 
              in 2024 with a passion for helping businesses transform through innovative technology 
              solutions and strategic risk management.
            </p>
            <p className="text-base md:text-lg leading-relaxed" data-testid="text-bio-2">
              I specialize in improving enterprise technology solutions for our clients, with a 
              particular focus on AI integration in the business field. My approach combines 
              technical expertise with business acumen to deliver solutions that drive real value 
              and competitive advantage.
            </p>
            <p className="text-base md:text-lg leading-relaxed" data-testid="text-bio-3">
              What excites me most is AI's transformative potential in the consulting industry. 
              I'm constantly exploring how emerging technologies can solve complex business 
              challenges and create new opportunities for our clients.
            </p>
            <p className="text-base md:text-lg leading-relaxed" data-testid="text-bio-4">
              I'm hungry to rise through the ranks at ConsultForMe, driven by a desire to not 
              only excel individually but to eventually lead teams in pioneering AI-integrated 
              consulting solutions that shape the future of the industry.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
