import { ExternalLink, Github } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import jpmorganLogo from "@assets/generated_images/JPMorgan_Chase_logo_4adbb56e.png";
import goldmanLogo from "@assets/generated_images/Goldman_Sachs_logo_33a3c832.png";
import microsoftLogo from "@assets/generated_images/Microsoft_logo_a37f4c3a.png";
import jnjLogo from "@assets/generated_images/Johnson_&_Johnson_logo_9e94844a.png";

const projects = [
  {
    id: "analytics-dashboard",
    title: "Enterprise Risk Analytics Platform - JPMorgan Chase",
    description:
      "Developed comprehensive risk analytics solution for JPMorgan Chase, enabling real-time monitoring of technology risks across their global banking operations. Reduced risk assessment time by 60% through automated reporting and advanced data visualization.",
    image: jpmorganLogo,
    company: "JPMorgan Chase",
    technologies: ["PowerBI", "Python", "Azure", "SQL", "Power Automate"],
    githubUrl: "#",
    liveUrl: "#",
  },
  {
    id: "ecommerce-app",
    title: "AI-Powered Compliance System - Goldman Sachs",
    description:
      "Implemented machine learning solution to automate compliance monitoring for Goldman Sachs. System identifies potential regulatory violations and recommends corrective actions, improving compliance accuracy by 45% and reducing manual review time.",
    image: goldmanLogo,
    company: "Goldman Sachs",
    technologies: ["Python", "Azure ML", "ServiceNow", "Tableau"],
    githubUrl: "#",
    liveUrl: "#",
  },
  {
    id: "task-manager",
    title: "Cloud Migration Strategy - Microsoft",
    description:
      "Led technology assessment and Azure migration roadmap for Microsoft's enterprise clients. Delivered comprehensive risk analysis and mitigation strategies for transitioning legacy systems to cloud infrastructure, ensuring zero downtime during migration.",
    image: microsoftLogo,
    company: "Microsoft",
    technologies: ["AWS", "Azure", "Risk Assessment", "Cloud Security"],
    githubUrl: "#",
    liveUrl: "#",
  },
  {
    id: "portfolio-builder",
    title: "Cybersecurity Framework Enhancement - Johnson & Johnson",
    description:
      "Designed and implemented enhanced cybersecurity framework for Johnson & Johnson's healthcare operations. Conducted vulnerability assessments and deployed advanced monitoring solutions, strengthening overall security posture by 70%.",
    image: jnjLogo,
    company: "Johnson & Johnson",
    technologies: ["Cybersecurity", "Compliance", "Azure Security", "SIEM"],
    githubUrl: "#",
    liveUrl: "#",
  },
];

export default function Projects() {
  return (
    <section id="projects" className="py-16 md:py-24 bg-card">
      <div className="max-w-6xl mx-auto px-4">
        <h2
          className="text-3xl md:text-4xl font-bold mb-12 text-center"
          data-testid="text-projects-heading"
        >
          Featured Projects
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {projects.map((project) => (
            <Card
              key={project.id}
              className="overflow-hidden hover-elevate"
              data-testid={`card-project-${project.id}`}
            >
              <div className="aspect-video overflow-hidden bg-card flex items-center justify-center p-8">
                <img
                  src={project.image}
                  alt={project.company}
                  className="w-full h-full object-contain"
                  data-testid={`img-project-${project.id}`}
                />
              </div>
              <CardHeader>
                <CardTitle data-testid={`text-project-title-${project.id}`}>
                  {project.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p
                  className="text-muted-foreground mb-4"
                  data-testid={`text-project-description-${project.id}`}
                >
                  {project.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {project.technologies.map((tech) => (
                    <Badge
                      key={tech}
                      variant="secondary"
                      className="text-xs"
                      data-testid={`badge-tech-${project.id}-${tech.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}
                    >
                      {tech}
                    </Badge>
                  ))}
                </div>
              </CardContent>
              <CardFooter className="gap-2 flex-wrap">
                <Button
                  variant="outline"
                  size="sm"
                  asChild
                  data-testid={`button-github-${project.id}`}
                >
                  <a href={project.githubUrl} target="_blank" rel="noopener noreferrer">
                    <Github className="h-4 w-4 mr-2" />
                    GitHub
                  </a>
                </Button>
                <Button
                  variant="default"
                  size="sm"
                  asChild
                  data-testid={`button-live-${project.id}`}
                >
                  <a href={project.liveUrl} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Live Demo
                  </a>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
