import { Target, Rocket, Trophy } from "lucide-react";

const goals = [
  {
    id: "short-term",
    icon: Target,
    title: "Short-term Goals",
    description:
      "Provide the best possible solutions in my upcoming project with our next client. Deepen my expertise in AI applications for enterprise risk management and deliver measurable value that exceeds expectations. Build strong relationships with stakeholders and demonstrate my commitment to excellence.",
    timeline: "Next 6 months",
  },
  {
    id: "medium-term",
    icon: Rocket,
    title: "Medium-term Goals",
    description:
      "Earn a promotion at ConsultForMe and be entrusted with leading my own team. Develop a track record of successful client engagements and innovative solutions. Expand my expertise in AI integration across various industry verticals and establish myself as a go-to expert within the firm.",
    timeline: "1-2 years",
  },
  {
    id: "long-term",
    icon: Trophy,
    title: "Long-term Goals",
    description:
      "Become a team lead specializing in AI integration within the consulting field at ConsultForMe. Build and mentor a high-performing team that pioneers innovative AI-driven solutions for our clients. Shape the future of technology consulting by leading the firm's AI practice and establishing new industry standards.",
    timeline: "3-5 years",
  },
];

export default function Goals() {
  return (
    <section id="goals" className="py-16 md:py-24 bg-card">
      <div className="max-w-4xl mx-auto px-4">
        <h2
          className="text-3xl md:text-4xl font-bold mb-12 text-center"
          data-testid="text-goals-heading"
        >
          My Goals
        </h2>

        <div className="relative space-y-12">
          <div className="absolute left-8 top-8 bottom-8 w-0.5 bg-border hidden md:block" />

          {goals.map((goal, index) => {
            const Icon = goal.icon;
            return (
              <div
                key={goal.id}
                className="relative flex flex-col md:flex-row gap-6"
                data-testid={`card-goal-${goal.id}`}
              >
                <div className="flex items-start gap-4 md:gap-6">
                  <div className="relative z-10 bg-primary text-primary-foreground p-4 rounded-lg flex-shrink-0">
                    <Icon className="h-6 w-6" />
                  </div>
                  <div className="flex-1">
                    <div className="flex flex-col sm:flex-row sm:items-baseline gap-2 mb-3">
                      <h3
                        className="text-xl md:text-2xl font-semibold"
                        data-testid={`text-goal-title-${goal.id}`}
                      >
                        {goal.title}
                      </h3>
                      <span
                        className="text-sm font-medium text-muted-foreground"
                        data-testid={`text-goal-timeline-${goal.id}`}
                      >
                        {goal.timeline}
                      </span>
                    </div>
                    <p
                      className="text-base leading-relaxed text-muted-foreground"
                      data-testid={`text-goal-description-${goal.id}`}
                    >
                      {goal.description}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
