import { ArrowDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import heroImage from "@assets/generated_images/Hero_background_workspace_31aeb3dc.png";

export default function Hero() {
  const scrollToAbout = () => {
    const element = document.querySelector("#about");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section
      id="hero"
      className="relative h-[80vh] flex items-center justify-center overflow-hidden"
    >
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-black/70" />

      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <h1
          className="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6"
          data-testid="text-hero-name"
        >
          Bobby Chan
        </h1>
        <p
          className="text-xl md:text-2xl text-white/90 mb-4"
          data-testid="text-hero-tagline"
        >
          Technology Risk Consultant & AI Enthusiast
        </p>
        <p
          className="text-lg text-white/80 mb-8 max-w-2xl mx-auto"
          data-testid="text-hero-bio"
        >
          Passionate about transforming businesses through innovative technology solutions. Specializing in AI integration and enterprise risk management.
        </p>
        <Button
          size="lg"
          onClick={scrollToAbout}
          className="bg-primary/90 backdrop-blur-md hover:bg-primary border border-primary-border"
          data-testid="button-view-work"
        >
          View My Work
        </Button>
      </div>

      <button
        onClick={scrollToAbout}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/70 hover:text-white transition-colors animate-bounce"
        data-testid="button-scroll-indicator"
        aria-label="Scroll down"
      >
        <ArrowDown className="h-8 w-8" />
      </button>
    </section>
  );
}
