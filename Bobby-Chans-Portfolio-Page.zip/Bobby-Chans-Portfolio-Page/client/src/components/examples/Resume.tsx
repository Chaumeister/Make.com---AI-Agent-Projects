import Resume from "../Resume";

export default function ResumeExample() {
  return <Resume />;
}
