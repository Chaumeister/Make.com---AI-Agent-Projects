import CourseLearnings from "../CourseLearnings";

export default function CourseLearningsExample() {
  return <CourseLearnings />;
}
