import Goals from "../Goals";

export default function GoalsExample() {
  return <Goals />;
}
